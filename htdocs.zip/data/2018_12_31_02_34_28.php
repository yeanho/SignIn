        <div id="main_img_bar">
            <img src="./img/main_img.png">
        </div>
        <div id="main_content">
            <div id="latest">
                <h4>최근 게시글(16장)</h4>
                <ul>
                <li>
                    <span>안녕하세요!</span>
                    <span>홍길동</span>
                    <span>2019-05-01</span>
                </li>
                <li>
                    <span>안녕하세요!</span>
                    <span>홍길동</span>
                    <span>2019-05-01</span>
                </li>
                <li>
                    <span>안녕하세요!</span>
                    <span>홍길동</span>
                    <span>2019-05-01</span>
                </li>
                <li>
                    <span>안녕하세요!</span>
                    <span>홍길동</span>
                    <span>2019-05-01</span>
                </li>
                <li>
                    <span>안녕하세요!</span>
                    <span>홍길동</span>
                    <span>2019-05-01</span>
                </li>
                </ul>
            </div>
            <div id="point_rank">
                <h4>포인트 랭킹(16장)</h4>
                <ul>
                <li>
                    <span>1</span>
                    <span>강 * 욱</span>
                    <span>rubato</span>
                    <span>6000</span>
                </li>
                <li>
                    <span>2</span>
                    <span>김 * 경</span>
                    <span>sukim</span>
                    <span>5000</span>
                </li>
                <li>
                    <span>3</span>
                    <span>안 * 영</span>
                    <span>jyahn</span>
                    <span>4000</span>
                </li>
                <li>
                    <span>4</span>
                    <span>홍 * 수</span>
                    <span>jshong</span>
                    <span>3000</span>
                </li>
                <li>
                    <span>5</span>
                    <span>윤 * 문</span>
                    <span>smyoun</span>
                    <span>2000</span>
                </li>
                </ul>
            </div>
        </div>