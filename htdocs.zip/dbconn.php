<?php
    $db_host = 'localhost';
    $db_user = 'root';
    $db_pass = 'password';
    $db_name = 'web01';

    $con = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
?>
